/* CM-CAR-INTRO: انیمیشن ورود ماشین در هیرو (یک‌بار در هر بار لود سایت).
   - ماشین از راست می‌آید و با ease-out می‌ایستد؛ تایر هم‌زمان می‌چرخد (زاویه ∝ مسافت، همان easing).
   - پایانِ انیمیشن دقیقاً همان عکس اصلی است.
   - اگر صفحه در حین انیمیشن دوباره رندر شود، انیمیشن از همان لحظه ادامه می‌یابد. */
(function () {
  if (window.__cmCarIntro) return; window.__cmCarIntro = true;
  var DUR = 2800, EASE = "cubic-bezier(.16,.84,.28,1)";
  var SPIN_BOOST = 1.5;           /* چرخش کمی بیشتر از غلتیدن واقعی تا دیده شود */
  var TIRE_R = 129 / 735;         /* شعاع بیرونی تایر نسبت به عرض عکس */
  var t0 = 0, done = false;
  window.__cmCarIntroElapsed = function () { return t0 ? performance.now() - t0 : -1; };
  window.__cmCarIntroBusy = function () { return !t0 || performance.now() - t0 < DUR + 300; };
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

  function imgsReady(el) {
    var list = Array.prototype.slice.call(el.querySelectorAll("img"));
    var p = list.map(function (i) { return i.decode ? i.decode().catch(function () {}) : Promise.resolve(); });
    return Promise.race([Promise.all(p), new Promise(function (r) { setTimeout(r, 2500); })]);
  }
  /* کلمه‌به‌کلمه: متن را به span.cm-w می‌شکند (ساختار <em> حفظ می‌شود) */
  function words(el) {
    var out = [];
    if (!el) return out;
    (function walk(n) {
      Array.prototype.slice.call(n.childNodes).forEach(function (c) {
        if (c.nodeType === 3) {
          var frag = document.createDocumentFragment();
          c.nodeValue.split(/(\s+)/).forEach(function (s) {
            if (!s) return;
            if (/^\s+$/.test(s)) { frag.appendChild(document.createTextNode(" ")); return; }
            var sp = document.createElement("span"); sp.className = "cm-w"; sp.textContent = s; frag.appendChild(sp); out.push(sp);
          });
          n.replaceChild(frag, c);
        } else if (c.nodeType === 1) walk(c);
      });
    })(el);
    return out;
  }
  function play(stage, slide, elapsed) {
    var body = stage.querySelector(".cm-hp-car-body"), wheel = stage.querySelector(".cm-hp-wheel");
    if (!body || !wheel) { slide.classList.remove("ci-wait"); return; }
    var cw = stage.clientWidth, ch = stage.clientHeight;
    if (!cw || !ch) { slide.classList.remove("ci-wait"); return; }
    var wb = Math.max(cw, 1.5 * ch);
    var shift = (cw + wb) / 2 + 10;
    var spin = (shift / (TIRE_R * wb)) * 180 / Math.PI * SPIN_BOOST;
    var o = { duration: DUR, easing: EASE, fill: "both" };
    var lin = { duration: DUR, easing: "linear", fill: "both" };
    var anims = [
      body.animate([{ transform: "translateX(" + shift + "px)" }, { transform: "translateX(0)" }], o),
      wheel.animate([{ transform: "rotate(" + spin + "deg)" }, { transform: "rotate(0deg)" }], o),
      wheel.querySelector(".w-blur").animate([{ opacity: 1 }, { opacity: .85, offset: .3 }, { opacity: .2, offset: .65 }, { opacity: 0 }], lin),
      wheel.querySelector(".w-sharp").animate([{ opacity: 0 }, { opacity: .15, offset: .3 }, { opacity: .8, offset: .65 }, { opacity: 1 }], lin)
    ];
    var copy = slide.querySelector(".cm-hp-copy");
    if (copy) {
      /* جمله‌به‌جمله: اول تیتر، بعد زیرتیتر، بعد دکمه‌ها، بعد استوری‌ها؛ همه پیش از پایان حرکت ماشین (DUR) کامل می‌شوند */
      var WE = "cubic-bezier(.2,.8,.2,1)";
      var rise = function (el, delay, dur) { if (el) anims.push(el.animate([{ opacity: 0, transform: "translateY(16px)" }, { opacity: 1, transform: "none" }], { duration: dur, delay: delay, easing: WE, fill: "both" })); };
      rise(copy.querySelector("h1"), 800, 650);
      rise(copy.querySelector("p"), 1150, 650);
      rise(copy.querySelector(".cm-hp-actions"), 1400, 600);
      /* استوری‌ها تا لحظه‌ی ۱۵۰۰ms پنهان می‌مانند؛ دایره‌ها را cm-reveal.js یکی‌یکی از همان لحظه نشان می‌دهد */
      var spw = document.querySelector(".cm-sp-wrap");
      if (spw) anims.push(spw.animate([{ opacity: 0 }, { opacity: 0, offset: .999 }, { opacity: 1 }], { duration: 1500, easing: "linear", fill: "both" }));
      slide.classList.add("ci-in");
    }
    slide.classList.remove("ci-wait");
    anims.forEach(function (a) { a.currentTime = elapsed; a.onfinish = function () { try { a.cancel(); } catch (_) {} }; });
  }
  function start(stage, slide) {
    if (done) { slide.classList.remove("ci-wait"); return; }
    var elapsed = t0 ? performance.now() - t0 : 0;
    if (elapsed >= DUR + 1500) { done = true; slide.classList.remove("ci-wait"); return; }
    if (!t0) {
      imgsReady(stage).then(function () {
        if (!stage.isConnected) return;
        var go = function () {
          if (!t0) t0 = performance.now();
          play(stage, slide, performance.now() - t0);
        };
        if (document.hidden) document.addEventListener("visibilitychange", function f() { if (!document.hidden) { document.removeEventListener("visibilitychange", f); go(); } });
        else go();
      });
    } else play(stage, slide, elapsed);
  }
  function scan() {
    var list = document.querySelectorAll(".cm-hp-car:not([data-ci])");
    for (var i = 0; i < list.length; i++) {
      var st = list[i]; st.setAttribute("data-ci", "1");
      var slide = st.closest(".cm-hp-slide");
      if (!slide) continue;
      if (reduce) continue;
      slide.classList.add("ci-wait");
      start(st, slide);
    }
  }
  function boot() {
    scan();
    if ("MutationObserver" in window) new MutationObserver(scan).observe(document.body || document.documentElement, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
