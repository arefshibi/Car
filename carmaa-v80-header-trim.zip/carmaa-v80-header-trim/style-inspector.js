/* CarMaa Style Inspector — live CSS editor with suggestions, site palette and !important overrides.
 * Enable with ?inspect=1; disable and clear local edits with ?inspect=0.
 */
(function () {
  "use strict";
  if (window.__cmStyleInspector) return;
  window.__cmStyleInspector = true;
  var W = window, D = document, FLAG = "cmStyleInspector", DATA = "cmStyleInspectorEdits", POS = "cmStyleInspectorPosition", ORDER_DATA = "cmStyleInspectorOrders";
  var query; try { query = new URLSearchParams(location.search); } catch (_) { query = null; }
  var switcher = query && query.get("inspect");
  function read(k) { try { return localStorage.getItem(k); } catch (_) { return null; } }
  function write(k, v) { try { localStorage.setItem(k, v); return true; } catch (_) { return false; } }
  function drop(k) { try { localStorage.removeItem(k); } catch (_) {} }
  if (switcher === "1") write(FLAG, "1");
  if (switcher === "0") { drop(FLAG); drop(DATA); drop(POS); drop(ORDER_DATA); }
  if (read(FLAG) !== "1") return;

  function json(s, fallback) { try { return JSON.parse(s); } catch (_) { return fallback; } }
  function escapeCss(s) {
    if (W.CSS && W.CSS.escape) return W.CSS.escape(String(s));
    return String(s).replace(/[^a-zA-Z0-9_-]/g, function (c) { return "\\" + c; });
  }
  function escHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function validProp(p) { return /^(?:--[\w-]+|[a-z][a-z0-9-]*)$/.test(String(p || "")); }
  function validValue(v) { return typeof v === "string" && v.length <= 500 && !/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(v); }
  function queryAll(sel) { try { return Array.prototype.slice.call(D.querySelectorAll(sel)); } catch (_) { return []; } }
  function isTool(el) { return !!(el && el.closest && el.closest("#cm-si-panel,#cm-si-fab,#cm-si-pickbar,#cm-si-highlight,#cm-si-toast")); }

  var groups = [
    { id: "layout", name: "چیدمان", items: [["display","نمایش"],["position","موقعیت"],["width","عرض"],["height","ارتفاع"],["min-width","حداقل عرض"],["max-width","حداکثر عرض"],["min-height","حداقل ارتفاع"],["max-height","حداکثر ارتفاع"],["z-index","لایه (Z-index)"],["overflow","سرریز"],["flex-direction","جهت Flex"],["justify-content","توزیع افقی"],["align-items","تراز عمودی"],["grid-template-columns","ستون‌های Grid"],["gap","فاصله آیتم‌ها"]] },
    { id: "space", name: "فاصله‌ها", items: [["margin","حاشیه بیرونی"],["margin-top","حاشیه بالا"],["margin-right","حاشیه راست"],["margin-bottom","حاشیه پایین"],["margin-left","حاشیه چپ"],["padding","فاصله داخلی"],["padding-top","فاصله داخلی بالا"],["padding-right","فاصله داخلی راست"],["padding-bottom","فاصله داخلی پایین"],["padding-left","فاصله داخلی چپ"],["row-gap","فاصله ردیف"],["column-gap","فاصله ستون"]] },
    { id: "type", name: "متن و فونت", items: [["font-family","نوع فونت"],["font-size","اندازه فونت"],["font-weight","ضخامت فونت"],["line-height","ارتفاع خط"],["letter-spacing","فاصله حروف"],["text-align","تراز متن"],["text-transform","حالت حروف"],["white-space","شکستن خط"],["text-decoration","تزئین متن"],["direction","جهت نوشتار"]] },
    { id: "color", name: "رنگ و شفافیت", items: [["color","رنگ متن"],["background","پس‌زمینه کامل"],["background-color","رنگ پس‌زمینه"],["opacity","شفافیت"],["visibility","قابلیت دیدن"]] },
    { id: "border", name: "کادر و سایه", items: [["border","کادر کامل"],["border-radius","گردی گوشه‌ها"],["border-width","ضخامت کادر"],["border-style","نوع کادر"],["border-color","رنگ کادر"],["box-shadow","سایه"],["outline","خط دور"],["filter","فیلتر"],["backdrop-filter","فیلتر پس‌زمینه"]] },
    { id: "more", name: "پیشرفته", items: [["transform","تبدیل"],["cursor","نشانگر ماوس"],["object-fit","نحوه قرارگیری تصویر"],["object-position","جایگاه تصویر"],["vertical-align","تراز عمودی"],["flex","Flex"],["order","ترتیب"],["grid-column","ستون Grid"],["grid-row","ردیف Grid"],["transition","انیمیشن تغییر"],["pointer-events","رویداد اشاره‌گر"]] }
  ];
  function loadEdits() {
    var raw = json(read(DATA) || "[]", []), out = [];
    if (!Array.isArray(raw)) return out;
    raw.slice(0, 250).forEach(function (e) {
      if (!e || typeof e.sel !== "string" || !e.sel || e.sel.length > 900 || (e.scope !== "single" && e.scope !== "similar") || !e.props || typeof e.props !== "object") return;
      var p = {};
      Object.keys(e.props).slice(0, 100).forEach(function (k) { var v = e.props[k]; if (validProp(k) && validValue(v) && v.trim()) p[k] = v; });
      if (Object.keys(p).length) out.push({ sel: e.sel, scope: e.scope, props: p });
    });
    return out;
  }
  var edits = loadEdits(), current = null, exactSelector = "", similarSelector = "", scope = "single", groupId = "layout";
  var orders = loadOrders(), reordering = false, reorderPicking = false, reorderParent = null, reorderRecord = null, reorderCurrentEl = null, orderSeq = 0;
  var opened = false, picking = false, dragPanel = null, dragFab = null, skipFabClick = false;
  var originalInline = new WeakMap(), applied = [], pendingApply = 0;

  function saveEdits() { write(DATA, JSON.stringify(edits)); }
  function findEntry(sel, sc) { for (var i = 0; i < edits.length; i++) if (edits[i].sel === sel && edits[i].scope === sc) return edits[i]; return null; }
  function ensureEntry(sel, sc) { return findEntry(sel, sc) || (function () { var e = { sel: sel, scope: sc, props: {} }; edits.push(e); return e; })(); }
  function getSelectorSegment(el) {
    if (el.id && !/^\d/.test(el.id)) return "#" + escapeCss(el.id);
    var tag = el.tagName.toLowerCase(), cl = [];
    if (el.classList) for (var i = 0; i < el.classList.length && cl.length < 3; i++) {
      var c = el.classList[i];
      if (c && c.length < 60 && !/^(active|open|show|hidden|selected|current|focus|hover|loading|disabled|is-|has-|js-)/i.test(c)) cl.push("." + escapeCss(c));
    }
    return tag + cl.join("");
  }
  function isUnique(sel, el) { try { var a = D.querySelectorAll(sel); return a.length === 1 && a[0] === el; } catch (_) { return false; } }
  function makeExactSelector(el) {
    var path = [], node = el, depth = 0;
    while (node && node.nodeType === 1 && node !== D.body && node !== D.documentElement && depth++ < 10) {
      var seg = getSelectorSegment(node);
      if (node.parentElement) {
        var siblings = node.parentElement.children, same = 0, index = 0;
        for (var i = 0; i < siblings.length; i++) { try { if (siblings[i].matches(seg)) same++; } catch (_) {} if (siblings[i] === node) index = i + 1; }
        if (same > 1) seg += ":nth-child(" + index + ")";
      }
      path.unshift(seg);
      var full = path.join(" > ");
      if (isUnique(full, el)) return full;
      if (node.id) break;
      node = node.parentElement;
    }
    return path.join(" > ");
  }
  function makeSimilarSelector(el) {
    var cl = [];
    if (el.classList) for (var i = 0; i < el.classList.length && cl.length < 3; i++) {
      var c = el.classList[i];
      if (c && c.length < 60 && !/^(active|open|show|hidden|selected|current|focus|hover|loading|disabled|is-|has-|js-)/i.test(c)) cl.push("." + escapeCss(c));
    }
    return cl.length ? el.tagName.toLowerCase() + cl.join("") : el.tagName.toLowerCase();
  }

  /* ---------- جابه‌جایی واقعی بخش‌ها در بین خواهر/برادرهای DOM ---------- */
  function loadOrders() {
    var raw = json(read(ORDER_DATA) || "[]", []), out = [];
    if (!Array.isArray(raw)) return out;
    raw.slice(0, 80).forEach(function (r) {
      if (!r || typeof r.id !== "string" || typeof r.parent !== "string" || !Array.isArray(r.items) || !Array.isArray(r.order) || !Array.isArray(r.original) || r.items.length < 2 || r.items.length > 80) return;
      var keys = Object.create(null), items = [];
      r.items.forEach(function (it) {
        if (!it || typeof it.key !== "string" || typeof it.sel !== "string" || it.sel.length > 400 || keys[it.key]) return;
        keys[it.key] = 1; items.push({ key: it.key, sel: it.sel, label: String(it.label || "بخش").slice(0, 80) });
      });
      var validOrder = r.order.length === items.length && r.order.every(function (k) { return !!keys[k]; });
      var validOriginal = r.original.length === items.length && r.original.every(function (k) { return !!keys[k]; });
      if (items.length >= 2 && validOrder && validOriginal) out.push({ id: r.id, parent: r.parent, items: items, order: r.order.slice(), original: r.original.slice() });
    });
    return out;
  }
  function saveOrders() { write(ORDER_DATA, JSON.stringify(orders)); }
  function orderLabel(el) {
    var txt = (el.getAttribute("aria-label") || el.getAttribute("title") || el.textContent || "").replace(/\s+/g, " ").trim();
    var id = el.id ? "#" + el.id : "";
    var cls = el.classList && el.classList.length ? "." + Array.prototype.slice.call(el.classList, 0, 2).join(".") : "";
    return (txt.slice(0, 34) || (el.tagName.toLowerCase() + id + cls)).slice(0, 80);
  }
  function directChildSelector(el, parent) {
    var tag = el.tagName.toLowerCase(), base = getSelectorSegment(el), siblings = Array.prototype.slice.call(parent.children);
    var matches = siblings.filter(function (n) { try { return n.matches(base); } catch (_) { return false; } });
    if (matches.length === 1) return base;
    var sameTagIndex = 0;
    for (var i = 0; i < siblings.length; i++) { if (siblings[i].tagName.toLowerCase() === tag) sameTagIndex++; if (siblings[i] === el) break; }
    return tag + ":nth-of-type(" + sameTagIndex + ")";
  }
  function visibleOrderChildren(parent) {
    return Array.prototype.filter.call(parent.children, function (el) {
      if (!el || isTool(el) || /^(SCRIPT|STYLE|LINK|META|TEMPLATE|NOSCRIPT)$/.test(el.tagName) || el.hidden) return false;
      try { var cs = getComputedStyle(el); return cs.display !== "none" && cs.visibility !== "hidden"; } catch (_) { return true; }
    });
  }
  function orderParentSelector(parent) {
    if (parent === D.body) return "body";
    if (parent === D.documentElement) return "html";
    return makeExactSelector(parent) || parent.tagName.toLowerCase();
  }
  function findOrderRecord(parent) {
    var selector = orderParentSelector(parent);
    for (var i = 0; i < orders.length; i++) if (orders[i].parent === selector) return orders[i];
    return null;
  }
  function resolveOrderNodes(record, parent) {
    var byKey = Object.create(null), marked = 0;
    Array.prototype.forEach.call(parent.children, function (el) {
      if (el.getAttribute("data-cm-si-order-id") === record.id) {
        var k = el.getAttribute("data-cm-si-order-key"); if (k) { byKey[k] = el; marked++; }
      }
    });
    if (marked === record.items.length) return byKey;
    byKey = Object.create(null);
    for (var i = 0; i < record.items.length; i++) {
      var item = record.items[i], matches = Array.prototype.filter.call(parent.children, function (el) { try { return el.matches(item.sel); } catch (_) { return false; } });
      if (matches.length !== 1) return null;
      byKey[item.key] = matches[0];
    }
    record.items.forEach(function (item) {
      byKey[item.key].setAttribute("data-cm-si-order-id", record.id);
      byKey[item.key].setAttribute("data-cm-si-order-key", item.key);
    });
    return byKey;
  }
  function recordOrderIsApplied(record, parent) {
    var seen = [];
    Array.prototype.forEach.call(parent.children, function (el) {
      if (el.getAttribute("data-cm-si-order-id") === record.id) seen.push(el.getAttribute("data-cm-si-order-key"));
    });
    return seen.length === record.order.length && seen.every(function (key, i) { return key === record.order[i]; });
  }
  function applyOrderRecord(record, parent) {
    if (!parent || recordOrderIsApplied(record, parent)) return false;
    var nodes = resolveOrderNodes(record, parent);
    if (!nodes) return false;
    var frag = D.createDocumentFragment();
    record.order.forEach(function (key) { if (nodes[key]) frag.appendChild(nodes[key]); });
    parent.appendChild(frag);
    return true;
  }
  function applySavedOrders() {
    orders.forEach(function (record) {
      var parents = queryAll(record.parent);
      if (parents.length === 1) applyOrderRecord(record, parents[0]);
    });
  }
  function ensureOrderRecord(parent) {
    var existing = findOrderRecord(parent);
    if (existing) return existing;
    var children = visibleOrderChildren(parent);
    if (children.length < 2 || children.length > 80) return null;
    var items = children.map(function (el, i) { return { key: "n" + i, sel: directChildSelector(el, parent), label: orderLabel(el) }; });
    var selectors = items.map(function (it) { return it.sel; });
    if (selectors.some(function (v, i) { return selectors.indexOf(v) !== i; })) return null;
    var keys = items.map(function (it) { return it.key; });
    var record = { id: "cm" + Date.now().toString(36) + (orderSeq++).toString(36), parent: orderParentSelector(parent), items: items, order: keys.slice(), original: keys.slice() };
    items.forEach(function (it, i) { children[i].setAttribute("data-cm-si-order-id", record.id); children[i].setAttribute("data-cm-si-order-key", it.key); });
    orders.push(record); saveOrders();
    return record;
  }
  function moveOrderKey(key, delta) {
    if (!reorderRecord || !reorderParent) return;
    var from = reorderRecord.order.indexOf(key), to = Math.max(0, Math.min(reorderRecord.order.length - 1, from + delta));
    if (from < 0 || from === to) return;
    var next = reorderRecord.order.slice(), moved = next.splice(from, 1)[0]; next.splice(to, 0, moved);
    reorderRecord.order = next;
    applyOrderRecord(reorderRecord, reorderParent);
    saveOrders(); if (reorderCurrentEl && reorderCurrentEl.isConnected) highlightElement(reorderCurrentEl); renderReorder();
  }
  function dropOrderKey(key, targetKey) {
    if (!reorderRecord || key === targetKey) return;
    var next = reorderRecord.order.slice(), from = next.indexOf(key), to = next.indexOf(targetKey);
    if (from < 0 || to < 0) return;
    next.splice(from, 1); next.splice(next.indexOf(targetKey), 0, key);
    reorderRecord.order = next; applyOrderRecord(reorderRecord, reorderParent); saveOrders(); if (reorderCurrentEl && reorderCurrentEl.isConnected) highlightElement(reorderCurrentEl); renderReorder();
  }
  function selectReorderElement(el) {
    if (!el || !el.parentElement || el === D.body || el === D.documentElement) { toast("این بخش قابل جابه‌جایی نیست"); return; }
    var children = visibleOrderChildren(el.parentElement);
    if (children.indexOf(el) < 0 || children.length < 2) { toast("این المنت هم‌سطح دیگری برای جابه‌جایی ندارد؛ بخش اصلی‌تری را انتخاب کن"); return; }
    var record = ensureOrderRecord(el.parentElement);
    if (!record) { toast("ساختار این بخش برای مرتب‌سازی امن مناسب نیست"); return; }
    reorderParent = el.parentElement; reorderRecord = record; reorderCurrentEl = el;
    reorderPicking = false; pickbar.hidden = true; opened = true; panel.hidden = false;
    highlightElement(el); renderReorder(); clampPanel();
  }

  function remember(el, prop) {
    var map = originalInline.get(el);
    if (!map) { map = Object.create(null); originalInline.set(el, map); }
    if (!Object.prototype.hasOwnProperty.call(map, prop)) map[prop] = { value: el.style.getPropertyValue(prop), priority: el.style.getPropertyPriority(prop) };
    return map[prop];
  }
  function restoreApplied() {
    for (var i = applied.length - 1; i >= 0; i--) {
      var r = applied[i], map = originalInline.get(r.el), old = map && map[r.prop];
      if (!old || !r.el || !r.el.style) continue;
      if (old.value) r.el.style.setProperty(r.prop, old.value, old.priority);
      else r.el.style.removeProperty(r.prop);
    }
    applied = [];
  }
  function applyAll() {
    restoreApplied();
    edits.forEach(function (entry) {
      queryAll(entry.sel).forEach(function (el) {
        if (!el || el.nodeType !== 1 || isTool(el)) return;
        Object.keys(entry.props).forEach(function (prop) {
          if (!validProp(prop)) return;
          remember(el, prop);
          el.style.setProperty(prop, entry.props[prop], "important");
          applied.push({ el: el, prop: prop });
        });
      });
    });
  }
  function queueApply() {
    if (pendingApply) return;
    pendingApply = W.requestAnimationFrame(function () { pendingApply = 0; applySavedOrders(); applyAll(); });
  }
  applySavedOrders();
  applyAll();
  try {
    new MutationObserver(function (records) {
      for (var i = 0; i < records.length; i++) if (records[i].type === "childList" || records[i].attributeName !== "style") { queueApply(); break; }
    }).observe(D.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ["class","id","data-page","data-section","data-tab","data-dock"] });
  } catch (_) {}

  var css = D.createElement("style"); css.id = "cm-si-css";
  css.textContent = [
    "#cm-si-panel,#cm-si-panel *,#cm-si-fab,#cm-si-fab *,#cm-si-pickbar,#cm-si-pickbar *,#cm-si-toast{box-sizing:border-box}",
    "#cm-si-fab{position:fixed;z-index:2147483644;right:14px;bottom:calc(104px + env(safe-area-inset-bottom,0px));width:54px;height:54px;border:1px solid rgba(255,255,255,.24);border-radius:18px;background:#17202c;color:#fff;box-shadow:0 8px 28px rgba(0,0,0,.35);font:800 13px/1 Tahoma,sans-serif;display:grid;place-items:center;cursor:grab;touch-action:none;user-select:none}",
    "#cm-si-fab[hidden],#cm-si-panel[hidden],#cm-si-pickbar[hidden]{display:none!important}",
    "#cm-si-panel{position:fixed;z-index:2147483643;left:12px;top:72px;width:min(448px,calc(100vw - 24px));max-height:min(78vh,780px);max-height:min(78dvh,780px);display:flex;flex-direction:column;overflow:hidden;direction:rtl;text-align:right;color:#f3f5f8;background:#151a22;border:1px solid rgba(255,255,255,.14);border-radius:18px;box-shadow:0 18px 55px rgba(0,0,0,.48);font:13px/1.55 Vazirmatn,Tahoma,sans-serif;overscroll-behavior:contain}",
    "#cm-si-head{flex:none;display:flex;align-items:center;gap:9px;padding:10px 12px;background:#202936;border-bottom:1px solid rgba(255,255,255,.1);touch-action:none;cursor:grab;user-select:none}",
    "#cm-si-head strong{font-size:14px;flex:1}#cm-si-grip{color:#aeb9c8;font-size:18px;letter-spacing:2px;padding:0 4px}",
    "#cm-si-panel button{font:inherit;border:1px solid rgba(255,255,255,.15);border-radius:9px;background:#2a3544;color:#f4f6f9;padding:6px 10px;cursor:pointer;white-space:nowrap}",
    "#cm-si-panel button.primary{background:#e11d48;border-color:#e11d48;color:#fff;font-weight:700}#cm-si-panel button.active{background:#f3f5f8;color:#161c25;border-color:#f3f5f8}",
    "#cm-si-content{min-height:0;overflow:auto;overscroll-behavior:contain;padding:10px 12px 14px;-webkit-overflow-scrolling:touch}",
    "#cm-si-toolbar{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:9px}",
    "#cm-si-selector{direction:ltr;text-align:left;font:11px/1.5 ui-monospace,monospace;color:#c9d3df;background:#0b1017;border:1px solid rgba(255,255,255,.09);border-radius:9px;padding:8px;word-break:break-all;margin:8px 0}",
    "#cm-si-meta{font-size:11px;color:#a6b2c2;margin-bottom:8px}#cm-si-tabs{display:flex;gap:6px;overflow-x:auto;padding:2px 0 9px;scrollbar-width:thin}",
    "#cm-si-tabs button{flex:none;font-size:11px;padding:6px 9px}#cm-si-fields{display:grid;grid-template-columns:1fr 1fr;gap:8px}",
    "#cm-si-fields .field{min-width:0;background:#1d2632;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:7px}#cm-si-fields label{display:block;font-size:11px;color:#c0cad7;margin-bottom:4px}",
    "#cm-si-fields input,#cm-si-custom input{display:block;width:100%;min-width:0;height:35px;border:1px solid rgba(255,255,255,.13);border-radius:7px;background:#0d131b;color:#fff;padding:0 8px;outline:none;font:12px/1.2 ui-monospace,monospace;direction:ltr;text-align:left}",
    "#cm-si-fields input:focus,#cm-si-custom input:focus{border-color:#e11d48;box-shadow:0 0 0 2px rgba(225,29,72,.16)}",
    "#cm-si-fields .cm-si-value-row{display:flex;gap:6px;align-items:center;direction:ltr}#cm-si-fields .cm-si-value-row>input{flex:1;min-width:0;width:auto}",
    "#cm-si-fields .cm-si-color-indicator{width:25px;height:25px;flex:none;border:2px solid rgba(255,255,255,.55);border-radius:7px;box-shadow:0 0 0 1px rgba(0,0,0,.35)}",
    "#cm-si-fields .cm-si-suggestions{display:flex;flex-wrap:wrap;gap:4px;margin-top:7px;align-items:center}#cm-si-fields .cm-si-suggestions>span{width:100%;font-size:10px;color:#8998aa}#cm-si-fields .cm-si-suggestions button{max-width:100%;font-size:10px;line-height:1.4;padding:3px 6px;direction:ltr;white-space:normal;overflow-wrap:anywhere;background:#263344}",
    "#cm-si-fields .cm-si-color-tools{display:flex;margin-top:6px}#cm-si-fields .cm-si-color-picker{display:inline-flex;align-items:center;gap:7px;border:1px solid rgba(255,255,255,.14);border-radius:8px;padding:4px 7px;background:#263344;color:#e7edf5;font-size:10px;cursor:pointer}#cm-si-fields .cm-si-color-picker input{width:25px;height:24px;min-width:25px;padding:2px;border:0;border-radius:5px;background:transparent;cursor:pointer}#cm-si-fields .cm-si-color-picker span{margin:0;color:inherit}#cm-si-fields .cm-si-color-picker input{width:25px;min-width:25px;height:24px}",
    "#cm-si-fields .cm-si-palette{margin-top:6px;border:1px solid rgba(255,255,255,.09);border-radius:8px;background:#17212d;padding:5px 7px}#cm-si-fields .cm-si-palette summary{font-size:10px;color:#c5d0de;cursor:pointer;list-style-position:inside}#cm-si-fields .cm-si-palette small{color:#91a0b1;font-size:10px}#cm-si-fields .cm-si-swatches{display:flex;flex-wrap:wrap;gap:6px;padding:7px 1px 2px;direction:ltr}#cm-si-fields .cm-si-swatch{width:25px;height:25px;padding:2px;border-radius:7px;background:#101720;border:1px solid rgba(255,255,255,.22);display:grid;place-items:center}#cm-si-fields .cm-si-swatch i{display:block;width:100%;height:100%;border-radius:4px;border:1px solid rgba(255,255,255,.2)}",
    "#cm-si-custom-suggestions{display:flex;flex-wrap:wrap;gap:5px;margin-top:7px}#cm-si-custom-suggestions button{font-size:10px;direction:ltr}#cm-si-fields .cm-si-color-indicator{background-color:transparent}",
    "#cm-si-order-note{font-size:12px;color:#c2cedb;line-height:1.9;background:#202b39;border:1px solid rgba(255,255,255,.09);border-radius:10px;padding:9px;margin:8px 0}#cm-si-order-list{display:flex;flex-direction:column;gap:7px;margin-top:10px}#cm-si-order-list .order-row{display:flex;align-items:center;gap:7px;padding:8px;border:1px solid rgba(255,255,255,.1);border-radius:10px;background:#1c2632;min-width:0}#cm-si-order-list .order-row.selected{border-color:#fb7185;background:#35232d}#cm-si-order-list .order-label{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px}#cm-si-order-list .order-pos{font:10px ui-monospace,monospace;color:#9aa9ba;min-width:24px}#cm-si-order-list .order-controls{display:flex;gap:4px;flex:none}#cm-si-order-list .order-controls button{min-width:32px;padding:5px 7px;font-size:13px}#cm-si-order-list .order-controls button:disabled{opacity:.28;cursor:default}#cm-si-order-actions{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px}#cm-si-order-actions button{flex:1}",
    "#cm-si-fields .foot{display:flex;align-items:center;justify-content:space-between;gap:5px;margin-top:4px}#cm-si-fields .foot span{font-size:10px;color:#8593a5;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}#cm-si-fields .foot button{font-size:10px;padding:2px 6px}",
    "#cm-si-custom{display:grid;grid-template-columns:1fr 1.3fr auto;gap:6px;margin-top:11px;padding-top:10px;border-top:1px solid rgba(255,255,255,.1)}#cm-si-custom input{height:36px;border-radius:8px;font-size:11px}",
    "#cm-si-note{font-size:10px;color:#9ca9b8;line-height:1.7;margin-top:9px}#cm-si-actions{display:flex;gap:7px;flex-wrap:wrap;margin-top:11px;padding-top:9px;border-top:1px solid rgba(255,255,255,.1)}",
    "#cm-si-pickbar{position:fixed;z-index:2147483645;left:50%;top:12px;transform:translateX(-50%);display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:12px;background:#e11d48;color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.3);font:12px Tahoma,sans-serif;white-space:nowrap;pointer-events:none}#cm-si-pickbar button{pointer-events:auto;border:0;border-radius:8px;background:#fff;color:#b0163a;padding:6px 10px;font:700 12px Tahoma,sans-serif}",
    "#cm-si-highlight{position:fixed;z-index:2147483642;pointer-events:none;display:none;border:2px solid #ff2c68;background:rgba(255,44,104,.13);border-radius:4px;box-shadow:0 0 0 1px rgba(255,255,255,.35)}",
    "#cm-si-toast{position:fixed;z-index:2147483646;left:50%;bottom:calc(85px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);padding:8px 14px;border-radius:999px;background:#f3f5f8;color:#18202b;font:600 12px Tahoma,sans-serif;box-shadow:0 5px 22px rgba(0,0,0,.28);display:none;white-space:nowrap}",
    "@media(max-width:600px){#cm-si-fab{width:50px;height:50px;border-radius:16px;right:10px;bottom:calc(92px + env(safe-area-inset-bottom,0px))}#cm-si-panel{left:8px;top:58px;width:calc(100vw - 16px);max-height:76vh;max-height:76dvh;border-radius:16px}#cm-si-content{padding:9px 10px 12px}#cm-si-fields{gap:6px}#cm-si-fields .field{padding:6px}#cm-si-fields input{height:36px;font-size:12px}#cm-si-head{padding:9px 10px}}"
  ].join("\n");
  (D.head || D.documentElement).appendChild(css);

  function element(tag, attrs, text) {
    var el = D.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) { el.setAttribute(k, attrs[k]); });
    if (text != null) el.textContent = text;
    return el;
  }
  var fab = element("button", { id: "cm-si-fab", type: "button", "aria-label": "بازرس استایل" }, "CSS");
  var panel = element("section", { id: "cm-si-panel", hidden: "", "aria-label": "بازرس استایل" });
  var pickbar = element("div", { id: "cm-si-pickbar", hidden: "" });
  pickbar.innerHTML = "<span>روی المنت موردنظر کلیک کن</span><button type='button' data-action='cancel-pick'>لغو انتخاب</button>";
  var highlight = element("div", { id: "cm-si-highlight" });
  var toastBox = element("div", { id: "cm-si-toast", role: "status" });
  D.body.appendChild(fab); D.body.appendChild(panel); D.body.appendChild(pickbar); D.body.appendChild(highlight); D.body.appendChild(toastBox);

  function toast(msg) {
    toastBox.textContent = msg; toastBox.style.display = "block";
    clearTimeout(toast._timer); toast._timer = setTimeout(function () { toastBox.style.display = "none"; }, 1500);
  }
  function highlightElement(el) {
    if (!el || !el.isConnected || isTool(el)) { highlight.style.display = "none"; return; }
    var r = el.getBoundingClientRect();
    highlight.style.cssText = "display:block;left:" + Math.max(0, r.left) + "px;top:" + Math.max(0, r.top) + "px;width:" + Math.max(0, r.width) + "px;height:" + Math.max(0, r.height) + "px";
  }
  function moveHighlight() { if (current) W.requestAnimationFrame(function () { highlightElement(current); }); }
  W.addEventListener("scroll", moveHighlight, true); W.addEventListener("resize", moveHighlight);

  function computed(prop) {
    if (!current) return "";
    try { return getComputedStyle(current).getPropertyValue(prop).trim(); } catch (_) { return ""; }
  }
  var sitePaletteCache = { at: 0, colors: [] }, siteFontCache = { at: 0, fonts: [] };
  function isColorProperty(prop) {
    return /(?:^|-)color$|^(?:color|background|fill|stroke|stop-color|flood-color|lighting-color)$/i.test(prop) || /(?:^|-)color(?:-|$)/i.test(prop);
  }
  function colorHex(value) {
    var v = String(value || "").trim();
    var m = v.match(/^#([0-9a-f]{3,8})$/i);
    if (m) {
      var h = m[1];
      if (h.length === 3 || h.length === 4) h = h.split("").map(function (c) { return c + c; }).join("");
      if (h.length === 6 || h.length === 8) return "#" + h.slice(0, 6).toLowerCase();
    }
    m = v.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+)%?)?\s*\)$/i);
    if (m) {
      var vals = [m[1], m[2], m[3]].map(function (n) { return Math.max(0, Math.min(255, Math.round(Number(n)))); });
      if (m[4] != null && Number(m[4]) <= 0) return "#000000";
      return "#" + vals.map(function (n) { return n.toString(16).padStart(2, "0"); }).join("");
    }
    return "";
  }
  function collectSiteColors() {
    var now = Date.now();
    if (now - sitePaletteCache.at < 5000 && sitePaletteCache.colors.length) return sitePaletteCache.colors;
    var counts = Object.create(null), nodes = queryAll("body *"), props = ["color", "background-color", "border-top-color", "border-right-color", "border-bottom-color", "border-left-color", "outline-color", "text-decoration-color", "fill", "stroke", "accent-color", "caret-color"];
    function add(value) {
      var c = String(value || "").trim();
      if (!c || c === "transparent" || c === "none") return;
      if (!/^(?:#[\da-f]{3,8}|rgba?\(|hsla?\(|color\()/i.test(c)) return;
      var alpha = c.match(/^rgba?\([^)]*[,/]\s*([\d.]+)%?\s*\)$/i);
      if (alpha && Number(alpha[1]) === 0) return;
      var key = (colorHex(c) || c).toLowerCase(); counts[key] = (counts[key] || 0) + 1;
    }
    var rootStyle;
    try { rootStyle = getComputedStyle(D.documentElement); } catch (_) { rootStyle = null; }
    if (rootStyle) {
      for (var ri = 0; ri < rootStyle.length; ri++) {
        var rk = rootStyle[ri];
        if (/^--/.test(rk) && /color/i.test(rk)) add(rootStyle.getPropertyValue(rk));
      }
    }
    for (var i = 0; i < nodes.length && i < 3500; i++) {
      var el = nodes[i]; if (isTool(el)) continue;
      try {
        var cs = getComputedStyle(el);
        for (var j = 0; j < props.length; j++) add(cs.getPropertyValue(props[j]));
        var bg = cs.backgroundImage;
        if (bg && bg !== "none") {
          var matches = bg.match(/#[\da-f]{3,8}\b|rgba?\([^)]*\)|hsla?\([^)]*\)/gi) || [];
          matches.forEach(add);
        }
      } catch (_) {}
    }
    var colors = Object.keys(counts).sort(function (a, b) { return counts[b] - counts[a]; }).slice(0, 28).map(function (value) { return { value: value, count: counts[value], hex: colorHex(value) }; });
    sitePaletteCache = { at: now, colors: colors };
    return colors;
  }
  function collectSiteFonts() {
    var now = Date.now();
    if (now - siteFontCache.at < 5000 && siteFontCache.fonts.length) return siteFontCache.fonts;
    var found = Object.create(null), nodes = queryAll("body *");
    for (var i = 0; i < nodes.length && i < 1800; i++) {
      if (isTool(nodes[i])) continue;
      try { var f = getComputedStyle(nodes[i]).fontFamily; if (f && f !== "inherit") found[f] = true; } catch (_) {}
    }
    ["Vazirmatn, Tahoma, sans-serif", "Tahoma, sans-serif", "Arial, sans-serif", "system-ui, sans-serif", "sans-serif"].forEach(function (f) { found[f] = true; });
    var fonts = Object.keys(found).slice(0, 14);
    siteFontCache = { at: now, fonts: fonts };
    return fonts;
  }
  var valueSuggestions = {
    display: ["block", "inline", "inline-block", "flex", "inline-flex", "grid", "inline-grid", "none"],
    position: ["static", "relative", "absolute", "fixed", "sticky"],
    overflow: ["visible", "hidden", "auto", "scroll", "clip"],
    "overflow-x": ["visible", "hidden", "auto", "scroll", "clip"], "overflow-y": ["visible", "hidden", "auto", "scroll", "clip"],
    "flex-direction": ["row", "column", "row-reverse", "column-reverse"],
    "flex-wrap": ["nowrap", "wrap", "wrap-reverse"],
    "justify-content": ["flex-start", "center", "flex-end", "space-between", "space-around", "space-evenly"],
    "align-items": ["stretch", "flex-start", "center", "flex-end", "baseline"],
    "align-content": ["stretch", "center", "flex-start", "flex-end", "space-between", "space-around"],
    "align-self": ["auto", "stretch", "center", "flex-start", "flex-end", "baseline"],
    "text-align": ["start", "center", "end", "justify", "left", "right"],
    "text-transform": ["none", "uppercase", "lowercase", "capitalize"],
    "white-space": ["normal", "nowrap", "pre", "pre-wrap", "pre-line", "break-spaces"],
    "text-decoration": ["none", "underline", "overline", "line-through"],
    "font-style": ["normal", "italic", "oblique"],
    "text-overflow": ["clip", "ellipsis"], "word-break": ["normal", "break-all", "keep-all", "break-word"],
    "overflow-wrap": ["normal", "anywhere", "break-word"],
    "background-clip": ["border-box", "padding-box", "content-box", "text"],
    "background-attachment": ["scroll", "fixed", "local"],
    "aspect-ratio": ["auto", "1 / 1", "4 / 3", "16 / 9", "3 / 2"],
    direction: ["rtl", "ltr"], visibility: ["visible", "hidden", "collapse"],
    "border-style": ["none", "solid", "dashed", "dotted", "double", "groove"],
    "outline-style": ["none", "solid", "dashed", "dotted", "double"],
    border: ["none", "1px solid currentColor", "1px solid #e5e7eb", "1px solid #d1d5db", "2px solid currentColor", "1px dashed currentColor"],
    outline: ["none", "1px solid currentColor", "2px solid #3b82f6", "2px dashed currentColor"],
    cursor: ["auto", "default", "pointer", "grab", "grabbing", "move", "text", "not-allowed", "help"],
    "object-fit": ["cover", "contain", "fill", "none", "scale-down"],
    "object-position": ["center", "top", "bottom", "left", "right", "center top", "center bottom"],
    "vertical-align": ["baseline", "middle", "top", "bottom", "text-top", "text-bottom"],
    "pointer-events": ["auto", "none"], "user-select": ["auto", "none", "text", "all"],
    "box-sizing": ["border-box", "content-box"], "background-repeat": ["no-repeat", "repeat", "repeat-x", "repeat-y"],
    "background-size": ["cover", "contain", "auto", "100% 100%"], "background-position": ["center", "top", "bottom", "left", "right", "center center"],
    "grid-auto-flow": ["row", "column", "dense", "row dense", "column dense"],
    "grid-template-columns": ["1fr", "1fr 1fr", "repeat(2, minmax(0, 1fr))", "repeat(3, minmax(0, 1fr))", "repeat(4, minmax(0, 1fr))", "auto 1fr"],
    "grid-template-rows": ["auto", "1fr", "auto 1fr", "repeat(2, auto)"],
    "list-style-type": ["none", "disc", "decimal", "circle", "square"],
    "font-weight": ["300", "400", "500", "600", "700", "800", "900", "bold"],
    "font-size": ["12px", "13px", "14px", "15px", "16px", "18px", "20px", "24px", "28px", "32px", "1rem", "1.25rem", "1.5rem"],
    "line-height": ["1", "1.2", "1.35", "1.5", "1.6", "1.8", "2", "normal"],
    "letter-spacing": ["normal", "-0.5px", "0", "0.5px", "1px", "1.5px", "2px"],
    "border-radius": ["0", "4px", "6px", "8px", "10px", "12px", "16px", "20px", "24px", "999px", "50%"],
    "border-width": ["0", "1px", "2px", "3px", "4px"], "outline-width": ["0", "1px", "2px", "3px"],
    "box-shadow": ["none", "0 1px 3px rgba(0,0,0,.12)", "0 4px 12px rgba(0,0,0,.12)", "0 8px 24px rgba(0,0,0,.16)", "0 12px 32px rgba(0,0,0,.2)", "0 0 0 1px rgba(0,0,0,.08)"],
    opacity: ["0", "0.1", "0.25", "0.5", "0.75", "0.9", "1"],
    "z-index": ["0", "1", "2", "10", "20", "50", "100", "999", "1000", "9999"],
    order: ["0", "1", "-1", "2", "3"], "flex-grow": ["0", "1", "2"], "flex-shrink": ["0", "1"],
    flex: ["1", "0 1 auto", "0 0 auto", "1 1 auto", "none", "auto"],
    "grid-column": ["auto", "1 / -1", "span 2", "span 3"], "grid-row": ["auto", "1 / -1", "span 2"],
    transform: ["none", "translateY(-2px)", "translateY(2px)", "scale(1.02)", "scale(0.98)", "rotate(0deg)"],
    transition: ["none", "all .15s ease", "all .2s ease", "all .3s ease", "transform .2s ease"],
    filter: ["none", "blur(0)", "brightness(1)", "grayscale(1)"], "backdrop-filter": ["none", "blur(8px)", "blur(12px)"]
  };
  function propertySuggestions(prop) {
    prop = String(prop || "").toLowerCase();
    if (isColorProperty(prop)) return [];
    if (valueSuggestions[prop]) return valueSuggestions[prop].slice(0, 9);
    if (prop === "font-family") return collectSiteFonts().slice(0, 8);
    if (/^(?:width|height|min-width|max-width|min-height|max-height|flex-basis)$/.test(prop)) return ["auto", "100%", "fit-content", "max-content", "min-content", "320px", "480px", "640px", "100vw"];
    if (/^(?:top|right|bottom|left|inset(?:-.*)?)$/.test(prop)) return ["0", "4px", "8px", "12px", "16px", "24px", "50%", "auto"];
    if (/^(?:margin|margin-.*)$/.test(prop)) return ["0", "auto", "4px", "8px", "12px", "16px", "24px", "-8px", "-16px", "1rem"];
    if (/^(?:padding|padding-.*|gap|row-gap|column-gap)$/.test(prop)) return ["0", "4px", "8px", "12px", "16px", "20px", "24px", "32px", "1rem", "1.5rem", "5%"];
    if (/(?:width|height|radius|spacing|offset|indent|thickness|size)$/.test(prop)) return ["0", "1px", "2px", "4px", "8px", "12px", "16px", "24px", "32px", "1rem", "100%"];
    if (/^(?:animation|animation-name)$/.test(prop)) return ["none", "fadeIn .2s ease", "slideUp .3s ease"];
    if (/^(?:background|background-image)$/.test(prop)) return ["none", "transparent", "linear-gradient(135deg, #111827, #334155)"];
    var val = current ? computed(prop) : "";
    if (/^-?\d+(?:\.\d+)?(?:px|rem|em|%|vh|vw)$/.test(val)) return ["0", "4px", "8px", "12px", "16px", "24px", "32px", "1rem", "100%"];
    if (/^-?\d+(?:\.\d+)?$/.test(val)) return ["0", "1", "2", "3", "4", "5", "10", "100"];
    return ["auto", "0", "none", "normal", "inherit", "initial", "unset"];
  }
  function suggestionMarkup(prop) {
    var vals = propertySuggestions(prop);
    if (!vals.length) return "";
    return "<div class='cm-si-suggestions'><span>پیشنهادها:</span>" + vals.map(function (v) {
      return "<button type='button' data-suggest-prop='" + escHtml(prop) + "' data-suggest-value='" + escHtml(v) + "' title='اعمال " + escHtml(v) + "'>" + escHtml(v) + "</button>";
    }).join("") + "</div>";
  }
  function colorToolsMarkup(prop, value) {
    if (!isColorProperty(prop)) return "";
    var hex = colorHex(value) || "#000000", colors = collectSiteColors().slice();
    var currentColor = String(value || "").trim(), currentKey = (colorHex(currentColor) || currentColor).toLowerCase();
    if (currentColor && /^(?:#[\da-f]{3,8}|rgba?\(|hsla?\(|color\()/i.test(currentColor) && !colors.some(function (c) { return (c.hex || c.value).toLowerCase() === currentKey || c.value.toLowerCase() === currentColor.toLowerCase(); })) {
      colors.unshift({ value: currentColor, count: 1, hex: colorHex(currentColor) });
      colors = colors.slice(0, 28);
    }
    var swatches = colors.map(function (c) {
      var styleColor = c.hex || c.value;
      return "<button type='button' class='cm-si-swatch' data-suggest-prop='" + escHtml(prop) + "' data-suggest-value='" + escHtml(c.value) + "' title='" + escHtml(c.value) + " · " + c.count + " بار' aria-label='انتخاب رنگ " + escHtml(c.value) + "'><i style='background-color:" + escHtml(styleColor) + "'></i></button>";
    }).join("");
    return "<div class='cm-si-color-tools'><label class='cm-si-color-picker' title='انتخاب رنگ دلخواه'><input type='color' data-prop='" + escHtml(prop) + "' data-color-picker value='" + hex + "' aria-label='انتخاب رنگ دلخواه'><span>انتخاب رنگ</span></label></div>" +
      "<details class='cm-si-palette'><summary>رنگ‌های استفاده‌شده در سایت (" + colors.length + ")</summary>" +
      (colors.length ? "<div class='cm-si-swatches'>" + swatches + "</div>" : "<small>رنگی از صفحه پیدا نشد.</small>") + "</details>";
  }
  function valueControlMarkup(prop, value) {
    var color = isColorProperty(prop);
    var indicator = color ? (colorHex(value) || "transparent") : "";
    return "<div class='cm-si-value-row'><input id='cm-si-field-" + escHtml(prop) + "' type='text' data-prop='" + escHtml(prop) + "' value='" + escHtml(value) + "' autocomplete='off' spellcheck='false' placeholder='مقدار CSS'>" +
      (color ? "<span class='cm-si-color-indicator' aria-hidden='true' style='background-color:" + indicator + "'></span>" : "") + "</div>" +
      (color ? colorToolsMarkup(prop, value) : suggestionMarkup(prop));
  }

  function activeSelector() { return scope === "single" ? exactSelector : similarSelector; }
  function activeEntry() { return findEntry(activeSelector(), scope); }
  function valueFor(prop) {
    var e = activeEntry();
    return e && Object.prototype.hasOwnProperty.call(e.props, prop) ? e.props[prop] : computed(prop);
  }
  function updateProperty(prop, value) {
    if (!current || !validProp(prop) || !validValue(value)) return;
    var sel = activeSelector(), entry = findEntry(sel, scope);
    if (!value.trim()) {
      if (entry) {
        delete entry.props[prop];
        if (!Object.keys(entry.props).length) edits.splice(edits.indexOf(entry), 1);
      }
    } else ensureEntry(sel, scope).props[prop] = value.trim();
    saveEdits(); applyAll();
    var status = panel.querySelector("[data-status='" + prop.replace(/[^a-z0-9_-]/gi, "") + "']");
    if (status) status.textContent = value.trim() ? "فعال · !important" : "مقدار اصلی";
  }
  function resetProperty(prop) {
    var e = activeEntry(); if (!e) return;
    delete e.props[prop];
    if (!Object.keys(e.props).length) edits.splice(edits.indexOf(e), 1);
    saveEdits(); applyAll(); render(); toast("ویژگی به حالت اصلی برگشت");
  }
  function resetCurrent() {
    var e = activeEntry();
    if (!e) { toast("تغییری برای بازنشانی نیست"); return; }
    edits.splice(edits.indexOf(e), 1); saveEdits(); applyAll(); render(); toast("تغییرات این انتخاب حذف شد");
  }
  function exportCss() {
    var out = ["/* CarMaa Style Inspector — CSS overrides */"];
    edits.forEach(function (e) {
      var keys = Object.keys(e.props).filter(validProp);
      if (!keys.length) return;
      out.push(":is(#cm-si-force-specificity, " + e.sel + ") {");
      keys.forEach(function (p) { out.push("  " + p + ": " + e.props[p] + " !important;"); });
      out.push("}");
    });
    return out.join("\n");
  }
  function copyText(text) {
    function fallback() {
      var ta = D.createElement("textarea"); ta.value = text;
      ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
      D.body.appendChild(ta); ta.focus(); ta.select();
      var ok = false; try { ok = D.execCommand("copy"); } catch (_) {}
      ta.remove(); toast(ok ? "کپی شد ✓" : "کپی انجام نشد");
    }
    if (navigator.clipboard && W.isSecureContext) navigator.clipboard.writeText(text).then(function () { toast("CSS کپی شد ✓"); }, fallback);
    else fallback();
  }
  function renderReorder() {
    if (!opened || !reordering) return;
    panel.hidden = false;
    var rows = "", currentKeys = reorderRecord ? reorderRecord.order : [];
    if (reorderRecord) {
      currentKeys.forEach(function (key, index) {
        var item = reorderRecord.items.filter(function (it) { return it.key === key; })[0];
        if (!item) return;
        var selectedKey = reorderCurrentEl && reorderCurrentEl.getAttribute("data-cm-si-order-id") === reorderRecord.id ? reorderCurrentEl.getAttribute("data-cm-si-order-key") : "";
        rows += "<div class='order-row" + (selectedKey === key ? " selected" : "") + "' draggable='true' data-order-row='" + escHtml(key) + "'><span class='order-pos'>" + (index + 1) + "</span><span class='order-label' title='" + escHtml(item.label) + "'>" + escHtml(item.label) + "</span><span class='order-controls'><button type='button' data-action='order-up' data-order-key='" + escHtml(key) + "' aria-label='انتقال به بالا' " + (index === 0 ? "disabled" : "") + ">↑</button><button type='button' data-action='order-down' data-order-key='" + escHtml(key) + "' aria-label='انتقال به پایین' " + (index === currentKeys.length - 1 ? "disabled" : "") + ">↓</button></span></div>";
      });
    }
    panel.innerHTML = "<div id='cm-si-head'><strong>جابه‌جایی بخش‌ها</strong><span id='cm-si-grip' title='برای جابه‌جایی پنل بکش'>⠿</span><button class='icon' type='button' data-action='close' aria-label='بستن'>✕</button></div>" +
      "<div id='cm-si-content'><div id='cm-si-toolbar'><button class='primary' type='button' data-action='select-order-target'>انتخاب بخش از صفحه</button><button type='button' data-action='return-css'>بازگشت به ویرایش CSS</button></div>" +
      (reorderRecord ? "<div id='cm-si-order-note'>بخش‌ها را با دکمه‌های ↑ و ↓ مرتب کن؛ در رایانه می‌توانی ردیف‌ها را هم بکشانی. ترتیب جدید در همین مرورگر ذخیره می‌شود.</div><div id='cm-si-order-list'>" + rows + "</div><div id='cm-si-order-actions'><button type='button' data-action='order-reset'>بازگردانی ترتیب اولیه</button><button type='button' data-action='order-copy'>کپی تنظیمات ترتیب</button></div><div id='cm-si-note'>فقط بخش‌هایی جابه‌جا می‌شوند که زیر یک والد مشترک باشند. برای جابه‌جایی بخش‌های نامرتبط، آن‌ها را در یک والد مشترک قرار بده.</div>" : "<div id='cm-si-order-note'>ابتدا دکمه «انتخاب بخش از صفحه» را بزن و یکی از بخش‌هایی را که می‌خواهی جابه‌جا کنی لمس کن. فهرست بخش‌های هم‌سطح آن نمایش داده می‌شود.</div>") +
      "</div>";
  }

  function render() {
    if (!opened) { panel.hidden = true; return; }
    panel.hidden = false;
    if (reordering) { renderReorder(); return; }
    var sel = activeSelector(), n = sel ? queryAll(sel).length : 0;
    var group = groups.filter(function (g) { return g.id === groupId; })[0] || groups[0];
    var fields = group.items.map(function (item) {
      var prop = item[0], value = valueFor(prop), entry = activeEntry();
      return "<div class='field'><label for='cm-si-field-" + escHtml(prop) + "'>" + escHtml(item[1]) + "</label>" +
        valueControlMarkup(prop, value) +
        "<div class='foot'><span data-status='" + escHtml(prop) + "'>" + (entry && entry.props[prop] ? "فعال · !important" : "مقدار فعلی") + "</span><button type='button' data-action='reset-prop' data-prop-reset='" + escHtml(prop) + "' title='بازنشانی این ویژگی'>↺</button></div></div>";
    }).join("");
    var customEntry = activeEntry(), customProps = customEntry ? Object.keys(customEntry.props).filter(function (p) { return !groups.some(function (g) { return g.items.some(function (it) { return it[0] === p; }); }); }) : [];
    var customHtml = customProps.map(function (p) {
      return "<div class='field'><label>ویژگی سفارشی · " + escHtml(p) + "</label>" + valueControlMarkup(p, customEntry.props[p]) + "<div class='foot'><span>فعال · !important</span><button type='button' data-action='reset-prop' data-prop-reset='" + escHtml(p) + "'>↺</button></div></div>";
    }).join("");
    var tabs = groups.map(function (g) { return "<button type='button' data-group='" + g.id + "' class='" + (groupId === g.id ? "active" : "") + "'>" + g.name + "</button>"; }).join("");
    var tag = current ? current.tagName.toLowerCase() : "—";
    var similarCount = similarSelector ? queryAll(similarSelector).length : 0;
    panel.innerHTML = "<div id='cm-si-head'><strong>بازرس استایل</strong><span id='cm-si-grip' title='برای جابه‌جایی بکش'>⠿</span><button class='icon' type='button' data-action='close' aria-label='بستن'>✕</button></div>" +
      "<div id='cm-si-content'>" +
      "<div id='cm-si-toolbar'><button class='primary' type='button' data-action='pick'>انتخاب المنت</button><button type='button' data-action='reorder-mode'>↕ جابه‌جایی بخش‌ها</button><button type='button' data-scope='single' class='" + (scope === "single" ? "active" : "") + "'>فقط همین یکی</button><button type='button' data-scope='similar' class='" + (scope === "similar" ? "active" : "") + "'>همه مشابه‌ها</button></div>" +
      (current ? "<div id='cm-si-selector'>" + escHtml(sel) + "</div><div id='cm-si-meta'>نوع: " + escHtml(tag) + " · " + n + " المنت با این انتخاب · " + similarCount + " مشابه</div>" : "<div id='cm-si-meta'>ابتدا «انتخاب المنت» را بزنید و سپس روی بخش موردنظر صفحه لمس کنید.</div>") +
      (current ? "<div id='cm-si-tabs'>" + tabs + "</div><div id='cm-si-fields'>" + fields + customHtml + "</div>" +
        "<div id='cm-si-custom'><input id='cm-si-new-prop' type='text' list='cm-si-prop-list' placeholder='ویژگی CSS، مثل letter-spacing' dir='ltr' autocomplete='off'><datalist id='cm-si-prop-list'><option value='color'><option value='background-color'><option value='font-size'><option value='font-weight'><option value='width'><option value='height'><option value='margin'><option value='padding'><option value='border-radius'><option value='box-shadow'><option value='gap'><option value='transform'><option value='display'><option value='position'></datalist><input id='cm-si-new-value' type='text' placeholder='مقدار پیشنهادی پس از انتخاب ویژگی' dir='ltr' autocomplete='off'><button type='button' data-action='add-custom'>افزودن</button></div><div id='cm-si-custom-suggestions'></div>" +
        "<div id='cm-si-note'>هر مقدار با اولویت <b dir='ltr'>!important</b> مستقیماً روی المنت اعمال می‌شود؛ بنابراین استایل‌های مهمِ تعریف‌شده در فایل‌های CSS نیز قابل بازنویسی هستند. تغییرات در همین مرورگر ذخیره می‌شوند.</div>" +
        "<div id='cm-si-actions'><button type='button' data-action='copy-css'>کپی CSS تغییرات</button><button type='button' data-action='reset-current'>بازنشانی این المنت</button><button type='button' data-action='clear-all'>حذف همه تغییرات</button></div>" : "<div id='cm-si-note'>پنل را از دستگیره بالای آن جابه‌جا کن. دکمه شناور CSS نیز قابل کشیدن است. برای ذخیره دائمی روی سایت، خروجی CSS را کپی و در فایل استایل پروژه قرار بده.</div><div id='cm-si-actions'><button type='button' data-action='copy-css'>کپی CSS تغییرات (" + edits.length + ")</button><button type='button' data-action='clear-all'>حذف همه تغییرات</button></div>") +
      "</div>";
  }

  function applySelection(el) {
    if (!el || el.nodeType !== 1 || isTool(el) || el === D.body || el === D.documentElement) return;
    current = el; exactSelector = makeExactSelector(el); similarSelector = makeSimilarSelector(el);
    scope = "single"; groupId = "layout"; opened = true; picking = false;
    fab.hidden = true; pickbar.hidden = true; render(); highlightElement(el); clampPanel();
  }
  function startReorderPicking() {
    reorderPicking = true; opened = false; panel.hidden = true; fab.hidden = true; pickbar.hidden = false;
    pickbar.innerHTML = "<span>بخشی را از صفحه انتخاب کن</span><button type='button' data-action='cancel-order-pick'>لغو</button>";
    highlight.style.display = "none";
  }
  function startPicking() {
    reordering = false; reorderPicking = false;
    picking = true; opened = false; panel.hidden = true; fab.hidden = true; pickbar.hidden = false;
    pickbar.innerHTML = "<span>روی المنت موردنظر کلیک کن</span><button type='button' data-action='cancel-pick'>لغو انتخاب</button>";
    highlight.style.display = "none";
  }

  function clampPanel() {
    if (!panel || panel.hidden) return;
    var r = panel.getBoundingClientRect(), x = r.left, y = r.top;
    x = Math.max(6, Math.min(x, W.innerWidth - Math.min(r.width, W.innerWidth - 12) - 6));
    y = Math.max(6, Math.min(y, W.innerHeight - Math.min(r.height, W.innerHeight - 12) - 6));
    panel.style.left = x + "px"; panel.style.top = y + "px"; panel.style.right = "auto"; panel.style.bottom = "auto";
  }
  function savePanelPosition() {
    var r = panel.getBoundingClientRect(), p = json(read(POS) || "{}", {});
    p.x = Math.round(r.left); p.y = Math.round(r.top); write(POS, JSON.stringify(p));
  }
  function restorePanelPosition() {
    var p = json(read(POS) || "null", null);
    if (p && isFinite(p.x) && isFinite(p.y)) { panel.style.left = p.x + "px"; panel.style.top = p.y + "px"; }
    clampPanel();
  }
  function saveFabPosition() {
    var r = fab.getBoundingClientRect();
    var p = json(read(POS) || "{}", {}); p.fx = Math.round(r.left); p.fy = Math.round(r.top); write(POS, JSON.stringify(p));
  }
  function restoreFabPosition() {
    var p = json(read(POS) || "{}", {});
    if (isFinite(p.fx) && isFinite(p.fy)) { fab.style.left = p.fx + "px"; fab.style.top = p.fy + "px"; fab.style.right = "auto"; fab.style.bottom = "auto"; }
  }
  restoreFabPosition();

  fab.addEventListener("click", function () {
    if (skipFabClick) { skipFabClick = false; return; }
    opened = !opened;
    if (opened) { fab.hidden = true; render(); restorePanelPosition(); }
    else { fab.hidden = false; panel.hidden = true; highlight.style.display = "none"; }
  });
  panel.addEventListener("click", function (ev) {
    var button = ev.target.closest("[data-action],[data-group],[data-scope],[data-suggest-prop],[data-custom-value]");
    if (!button || !panel.contains(button)) return;
    var action = button.getAttribute("data-action"), group = button.getAttribute("data-group"), sc = button.getAttribute("data-scope");
    if (group) { groupId = group; render(); return; }
    if (sc) { scope = sc; render(); return; }
    if (button.hasAttribute("data-suggest-prop")) {
      var targetProp = button.getAttribute("data-suggest-prop"), targetValue = button.getAttribute("data-suggest-value");
      var field = button.closest(".field"), textField = field && field.querySelector("input[data-prop='" + targetProp.replace(/'/g, "\\'") + "']:not([data-color-picker])");
      if (textField) textField.value = targetValue;
      var picker = field && field.querySelector("input[data-color-picker]");
      if (picker) { var hexValue = colorHex(targetValue); if (hexValue) picker.value = hexValue; }
      var indicator = field && field.querySelector(".cm-si-color-indicator"); if (indicator) indicator.style.backgroundColor = targetValue;
      updateProperty(targetProp, targetValue); toast("مقدار پیشنهادشده اعمال شد"); return;
    }
    if (button.hasAttribute("data-custom-value")) {
      var customValue = panel.querySelector("#cm-si-new-value"); if (customValue) customValue.value = button.getAttribute("data-custom-value"); return;
    }
    if (action === "close") { opened = false; reordering = false; reorderPicking = false; fab.hidden = false; panel.hidden = true; highlight.style.display = "none"; }
    else if (action === "reorder-mode") { reordering = true; reorderRecord = null; reorderParent = null; reorderCurrentEl = null; opened = true; renderReorder(); }
    else if (action === "select-order-target") startReorderPicking();
    else if (action === "return-css") { reordering = false; reorderPicking = false; render(); }
    else if (action === "order-up") moveOrderKey(button.getAttribute("data-order-key"), -1);
    else if (action === "order-down") moveOrderKey(button.getAttribute("data-order-key"), 1);
    else if (action === "order-reset") { if (reorderRecord) { reorderRecord.order = reorderRecord.original.slice(); applyOrderRecord(reorderRecord, reorderParent); saveOrders(); renderReorder(); toast("ترتیب اولیه بازگردانده شد"); } }
    else if (action === "order-copy") copyText(JSON.stringify({ version: 1, orders: orders }, null, 2));
    else if (action === "pick") startPicking();
    else if (action === "cancel-pick") { picking = false; fab.hidden = false; pickbar.hidden = true; render(); }
    else if (action === "copy-css") copyText(exportCss());
    else if (action === "reset-prop") resetProperty(button.getAttribute("data-prop-reset"));
    else if (action === "reset-current") resetCurrent();
    else if (action === "clear-all") {
      if (W.confirm("همه تغییرات ذخیره‌شده بازنشانی شوند؟")) { edits = []; saveEdits(); applyAll(); render(); toast("همه تغییرات پاک شد"); }
    }
    else if (action === "add-custom") {
      var name = panel.querySelector("#cm-si-new-prop"), value = panel.querySelector("#cm-si-new-value");
      var prop = name && name.value.trim(), val = value && value.value.trim();
      if (!validProp(prop)) { toast("نام ویژگی CSS معتبر نیست"); return; }
      if (!val || !validValue(val)) { toast("مقدار CSS را وارد کن"); return; }
      updateProperty(prop, val); render(); toast("ویژگی سفارشی اضافه شد");
    }
  });
  panel.addEventListener("input", function (ev) {
    var input = ev.target.closest("[data-prop]");
    if (input && panel.contains(input)) {
      var prop = input.getAttribute("data-prop"), field = input.closest(".field");
      if (input.hasAttribute("data-color-picker") && field) { var textField = field.querySelector("input[data-prop]:not([data-color-picker])"); if (textField) textField.value = input.value; }
      updateProperty(prop, input.value);
      if (field && !input.hasAttribute("data-color-picker")) { var colorPicker = field.querySelector("input[data-color-picker]"), hexColor = colorHex(input.value); if (colorPicker && hexColor) colorPicker.value = hexColor; }
      var indicator = field && field.querySelector(".cm-si-color-indicator"); if (indicator) indicator.style.backgroundColor = input.value;
    }
    if (ev.target && ev.target.id === "cm-si-new-prop") {
      var holder = panel.querySelector("#cm-si-custom-suggestions"), propName = ev.target.value.trim();
      if (holder) {
        var vals = propertySuggestions(propName);
        holder.innerHTML = vals.length ? "<span style='width:100%;font-size:10px;color:#9aa8b8'>پیشنهاد مقدار برای " + escHtml(propName) + ":</span>" + vals.map(function (v) { return "<button type='button' data-custom-value='" + escHtml(v) + "'>" + escHtml(v) + "</button>"; }).join("") : "";
      }
    }
  });
  panel.addEventListener("dragstart", function (ev) {
    var row = ev.target.closest("[data-order-row]");
    if (!reordering || !row) return;
    try { ev.dataTransfer.setData("text/plain", row.getAttribute("data-order-row")); ev.dataTransfer.effectAllowed = "move"; } catch (_) {}
  });
  panel.addEventListener("dragover", function (ev) {
    if (reordering && ev.target.closest("[data-order-row]")) { ev.preventDefault(); try { ev.dataTransfer.dropEffect = "move"; } catch (_) {} }
  });
  panel.addEventListener("drop", function (ev) {
    var row = ev.target.closest("[data-order-row]");
    if (!reordering || !row) return;
    ev.preventDefault();
    var from = ""; try { from = ev.dataTransfer.getData("text/plain"); } catch (_) {}
    dropOrderKey(from, row.getAttribute("data-order-row"));
  });
  pickbar.addEventListener("click", function (ev) {
    if (ev.target.closest("[data-action='cancel-order-pick']")) { reorderPicking = false; pickbar.hidden = true; fab.hidden = false; opened = true; renderReorder(); }
    else if (ev.target.closest("[data-action='cancel-pick']")) { picking = false; fab.hidden = false; pickbar.hidden = true; render(); }
  });

  D.addEventListener("pointermove", function (ev) {
    if (picking) {
      var target = ev.target && ev.target.nodeType === 1 ? ev.target : ev.target && ev.target.parentElement;
      if (target && !isTool(target)) highlightElement(target);
    }
    if (dragPanel) {
      var dx = ev.clientX - dragPanel.x, dy = ev.clientY - dragPanel.y;
      panel.style.left = (dragPanel.left + dx) + "px"; panel.style.top = (dragPanel.top + dy) + "px";
      panel.style.right = "auto"; panel.style.bottom = "auto"; clampPanel(); ev.preventDefault();
    }
    if (dragFab) {
      var fx = ev.clientX - dragFab.x, fy = ev.clientY - dragFab.y;
      if (!dragFab.moved && Math.abs(fx) + Math.abs(fy) > 7) dragFab.moved = true;
      if (dragFab.moved) {
        var r = fab.getBoundingClientRect();
        var nx = Math.max(4, Math.min(W.innerWidth - r.width - 4, dragFab.left + fx));
        var ny = Math.max(4, Math.min(W.innerHeight - r.height - 4, dragFab.top + fy));
        fab.style.left = nx + "px"; fab.style.top = ny + "px"; fab.style.right = "auto"; fab.style.bottom = "auto";
        ev.preventDefault();
      }
    }
  }, { passive: false });
  D.addEventListener("pointerup", function () {
    if (dragPanel) { dragPanel = null; savePanelPosition(); }
    if (dragFab) {
      if (dragFab.moved) { skipFabClick = true; saveFabPosition(); setTimeout(function () { skipFabClick = false; }, 300); }
      dragFab = null;
    }
  });
  panel.addEventListener("pointerdown", function (ev) {
    var head = ev.target.closest("#cm-si-head");
    if (!head || ev.target.closest("button")) return;
    var r = panel.getBoundingClientRect();
    dragPanel = { x: ev.clientX, y: ev.clientY, left: r.left, top: r.top };
    ev.preventDefault();
  });
  fab.addEventListener("pointerdown", function (ev) {
    var r = fab.getBoundingClientRect();
    dragFab = { x: ev.clientX, y: ev.clientY, left: r.left, top: r.top, moved: false };
  });
  D.addEventListener("click", function (ev) {
    if (!picking && !reorderPicking) return;
    var target = ev.target && ev.target.nodeType === 1 ? ev.target : ev.target && ev.target.parentElement;
    if (!target || isTool(target)) return;
    ev.preventDefault(); ev.stopPropagation(); ev.stopImmediatePropagation();
    if (reorderPicking) selectReorderElement(target); else applySelection(target);
  }, true);
  D.addEventListener("pointermove", function (ev) {
    if (!picking && !reorderPicking) return;
    var target = ev.target && ev.target.nodeType === 1 ? ev.target : ev.target && ev.target.parentElement;
    if (target && !isTool(target)) highlightElement(target);
  }, true);
  D.addEventListener("keydown", function (ev) {
    if (ev.key === "Escape") {
      if (reorderPicking) { reorderPicking = false; fab.hidden = false; pickbar.hidden = true; opened = true; renderReorder(); }
      else if (picking) { picking = false; fab.hidden = false; pickbar.hidden = true; render(); }
      else if (opened) { opened = false; reordering = false; fab.hidden = false; panel.hidden = true; highlight.style.display = "none"; }
    }
  });
  W.addEventListener("resize", function () { clampPanel(); });

  render();
})();
