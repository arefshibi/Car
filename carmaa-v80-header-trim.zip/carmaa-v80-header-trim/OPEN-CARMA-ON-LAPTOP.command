#!/bin/sh
cd "$(dirname "$0")"
PORT=8765
python3 -m http.server "$PORT" --bind 127.0.0.1 >/tmp/carmaa-local-preview.log 2>&1 &
SERVER_PID=$!
sleep 1
URL="http://127.0.0.1:$PORT/index.html?localPreview=1"
if command -v open >/dev/null 2>&1; then
  open "$URL"
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL"
else
  printf 'Open this address in your browser: %s\n' "$URL"
fi
printf 'CarMaa local preview server is running. Press Ctrl+C to stop it.\n'
wait "$SERVER_PID"
