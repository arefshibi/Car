/* CM-CINEMA v1: وقتی صفحه اسکرول شد، کلاس cmx-scrolled روی <html> می‌نشیند تا هدر شفافِ صفحه‌ی خانه بلور بگیرد. */
(function () {
  if (window.__cmCinema) return; window.__cmCinema = true;
  var root = document.documentElement, on = false, ticking = false, T = 16;
  function y() { return window.pageYOffset || root.scrollTop || document.body.scrollTop || 0; }
  function update() {
    ticking = false;
    var v = y() > (on ? T - 8 : T);      /* کمی hysteresis تا لرزش نکند */
    if (v !== on) { on = v; root.classList.toggle("cmx-scrolled", v); }
  }
  function req() { if (ticking) return; ticking = true; (window.requestAnimationFrame || setTimeout)(update); }
  window.addEventListener("scroll", req, { passive: true });
  window.addEventListener("resize", req);
  window.addEventListener("pageshow", req);
  window.addEventListener("popstate", req);
  var pc = document.getElementById("pageContent");
  if (pc && "MutationObserver" in window) new MutationObserver(req).observe(pc, { childList: true });
  update();
})();
