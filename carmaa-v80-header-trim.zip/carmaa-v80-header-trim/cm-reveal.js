/* CM-REVEAL v1 — ظاهر شدن نرم و پلکانی همه‌ی بخش‌ها و کارت‌ها هنگام ورود به صفحه (همان حس انیمیشن فوتر) */
(function () {
  "use strict";
  if (!("IntersectionObserver" in window) || !("MutationObserver" in window)) return;
  if (window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  var SEL = "main > * > *, .cm-hh > *, .cm-bento > *, .cm-pb-grid > *, article.cm-gc, article.cm-home-feature-showroom";
  var SKIP = ".cm-hh, .cm-sp-wrap, .cm-hh-promo, .cm-ft, .cm-ts, .cm-hb, .cm-hh-stories-head, .cm-skeleton-screen, .cm-sk2, script, style, template, [hidden], [data-no-reveal]";
  var seen = new WeakSet();
  var io = new IntersectionObserver(function (entries) {
    var vis = entries.filter(function (e) { return e.isIntersecting; })
      .sort(function (a, b) { return a.boundingClientRect.top - b.boundingClientRect.top || a.boundingClientRect.left - b.boundingClientRect.left; });
    vis.forEach(function (e, i) {
      var el = e.target; io.unobserve(el);
      el.style.setProperty("--rv-d", Math.min(i * 80, 480) + "ms");
      el.classList.remove("cm-rv"); el.classList.add("cm-rv-go");
      var done = function () { el.classList.remove("cm-rv-go"); el.style.removeProperty("--rv-d"); el.removeEventListener("animationend", done); };
      el.addEventListener("animationend", done);
      setTimeout(done, 1800);
    });
  }, { threshold: 0.01, rootMargin: "0px 0px -6% 0px" });
  function add(el) {
    if (seen.has(el) || (el.matches && el.matches(SKIP)) || (el.closest && el.closest(".cm-hh-promo, .cm-ft, .cm-skeleton-screen"))) return;
    seen.add(el); el.classList.add("cm-rv"); io.observe(el);
  }
  function scan(root) {
    if (root.nodeType !== 1) return;
    if (root.matches(SEL)) add(root);
    var l = root.querySelectorAll(SEL); for (var i = 0; i < l.length; i++) add(l[i]);
  }
  function start() {
    scan(document.body);
    new MutationObserver(function (ms) {
      for (var i = 0; i < ms.length; i++) for (var j = 0; j < ms[i].addedNodes.length; j++) scan(ms[i].addedNodes[j]);
    }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();

/* CM-SP-REPLAY — دایره‌های استوری هر بار که صفحه‌ی خانه دوباره ساخته می‌شود (بعد از انیمیشن اولِ هیرو) هم یکی‌یکی و روی هم ظاهر می‌شوند */
(function () {
  "use strict";
  if (!("MutationObserver" in window) || !document.documentElement.animate) return;
  if (window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  var E = "cubic-bezier(.2,.8,.2,1)";
  function play(w, tries) {
    if (w.__spDone) return;
    var items = Array.prototype.slice.call(w.querySelectorAll(".cm-sp-list .cm-sp-it")).filter(function (e) { return e.offsetParent; })
      .concat(Array.prototype.slice.call(w.querySelectorAll(".cm-sp-more, .cm-sp-add")));
    if (!items.length) return;
    var el = window.__cmCarIntroElapsed ? window.__cmCarIntroElapsed() : -1, base = 120;
    if (el < 0 && w.closest && w.closest(".cm-hh") && w.closest(".cm-hh").querySelector(".cm-hp-slide--car") && (tries || 0) < 40) {
      /* انیمیشن هیرو هنوز شروع نشده: صبر کن */
      setTimeout(function () { play(w, (tries || 0) + 1); }, 100); return;
    }
    w.__spDone = true;
    if (el >= 0 && el < 2800 + 300) base = Math.max(0, 1500 - el);   /* هم‌زمان با لحظه‌ی نمایان شدن ردیف استوری در انیمیشن هیرو */
    items.forEach(function (d, i) {
      d.animate([{ opacity: 0, transform: "scale(.35)" }, { opacity: 1, transform: "scale(1.08)", offset: .7 }, { opacity: 1, transform: "none" }], { duration: 480, delay: base + i * 95, easing: E, fill: "backwards" });
    });
  }
  function scan() { var l = document.querySelectorAll(".cm-sp-wrap"); for (var i = 0; i < l.length; i++) play(l[i]); }
  var q = 0;
  new MutationObserver(function () { if (q) return; q = 1; Promise.resolve().then(function () { q = 0; scan(); }); }).observe(document.body || document.documentElement, { childList: true, subtree: true });
})();
