/* ===== بک‌گراند هوشمند صفحه اصلی =====
   هر بخش را می‌شناسد (نقش + محتوا) و روشنایی پشتش را تعیین می‌کند:
   1) نقش بخش (هیرو، استوری، بنر، آگهی‌ها، نمایشگاه‌ها، برندها، فوتر…) → روشنایی پایه
   2) محتوای بخش: کارت‌های روشن → زمینه تیره‌تر | کارت‌های خیلی تیره → زمینه کمی روشن‌تر (جداسازی)
   3) رنگ تیتر: اگر تیتر تیره باشد زمینه روشن می‌شود (خوانایی)
   4) ریتم: بخش‌های مجاور حداقل ۵ واحد روشنایی فرق دارند تا پس‌زمینه ثابت/یکنواخت نشود
   5) با تغییر ارتفاع بخش‌ها (لود عکس/آگهی) خودکار دوباره محاسبه می‌شود. */
(function () {
  "use strict";
  var ROLES = [
    [/\bcm-hh\b/, 0, "hero"], [/\bcm-ts\b/, 2, "stories"], [/\bcm-uc\b/, 5, "usecase"],
    [/\bcm-pf\b/, 9, "filters"], [/\bcm-bt\b/, 1, "bodytype"], [/\bcm-pb\b/, 10, "brands"],
    [/--showrooms\b/, 8, "showrooms"], [/\bcm-hb\b/, 3, "banners"], [/\bcm-lt-sec\b/, 6, "latest"],
    [/\bcm-xp\b|\bcm-lt-promo\b/, 0, "promo"], [/--news\b/, 4, "news"], [/\bcm-ft\b/, 0, "footer"]
  ];
  var MIN_L = 0, MAX_L = 12, GAP = 3;

  function lum(rgb) {
    var m = rgb && rgb.match(/[\d.]+/g);
    if (!m || m.length < 3) return null;
    var a = m[3] === undefined ? 1 : +m[3];
    if (a < 0.6) return null;
    return (0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2]) / 255;
  }
  function role(el) {
    var cls = (el.className && el.className.toString()) || "";
    if (el.tagName === "FOOTER") cls += " cm-ft";
    for (var i = 0; i < ROLES.length; i++) if (ROLES[i][0].test(cls)) return { L: ROLES[i][1], name: ROLES[i][2] };
    return { L: 4, name: "other" };
  }
  function contentTone(el) {
    var nodes = el.querySelectorAll("*"), area = 0, sum = 0, n = Math.min(nodes.length, 250);
    var ar = el.getBoundingClientRect(), total = Math.max(1, ar.width * ar.height);
    for (var i = 0; i < n; i++) {
      var e = nodes[i], l = lum(getComputedStyle(e).backgroundColor);
      if (l === null) continue;
      var r = e.getBoundingClientRect(), a = r.width * r.height;
      if (a < 400 || a > total * 0.9) continue;
      area += a; sum += l * a;
    }
    return { coverage: area / total, avg: area ? sum / area : 0.5 };
  }
  function headingDark(el) {
    var h = el.querySelector("h1,h2,h3");
    if (!h) return false;
    var l = lum(getComputedStyle(h).color);
    return l !== null && l < 0.4;
  }
  function analyse(page) {
    var top0 = page.getBoundingClientRect().top + window.scrollY, out = [];
    Array.prototype.forEach.call(page.children, function (el) {
      var r = el.getBoundingClientRect();
      if (r.height < 60) return; // تیتر تکی/عنصر خالی
      var ro = role(el), L = ro.L, t = contentTone(el);
      if (t.coverage > 0.12) {
        if (t.avg > 0.6) L -= 2; else if (t.avg < 0.2) L += 2;
      }
      var dark = headingDark(el);
      out.push({ el: el, name: ro.name, top: r.top + window.scrollY - top0, h: r.height, L: L, headingDark: dark, cov: t.coverage, avg: t.avg });
    });
    for (var i = 1; i < out.length; i++) {
      if (out[i].headingDark) continue;
      var p = out[i - 1];
      if (Math.abs(out[i].L - p.L) < GAP) out[i].L = p.L >= 6 ? p.L - 4 : p.L + 4;
    }
    out.forEach(function (s) { s.L = s.headingDark ? 92 : Math.max(MIN_L, Math.min(MAX_L, s.L)); });
    return out;
  }
  function col(L, a) { return "hsla(0,0%," + L + "%," + (a === undefined ? 1 : a) + ")"; }
  function build(page, secs) {
    var H = Math.max(1, page.offsetHeight), stops = [], glows = [];
    secs.forEach(function (s, i) {
      var a = (s.top + s.h * 0.22) / H * 100, b = (s.top + s.h * 0.78) / H * 100;
      stops.push(col(s.L) + " " + a.toFixed(2) + "%", col(s.L) + " " + b.toFixed(2) + "%");
      if (s.L >= 7 && s.L <= 40) { // ناحیه‌ی روشن → درخشش سفید کمرنگ
        var cy = (s.top + s.h * 0.5) / H * 100, ry = Math.max(4, s.h / H * 60);
        glows.push("radial-gradient(" + (i % 2 ? "90%" : "100%") + " " + ry.toFixed(1) + "% at " + (i % 2 ? "100%" : "0%") + " " + cy.toFixed(1) + "%,rgba(255,255,255,.07),rgba(255,255,255,0) 72%)");
      }
    });
    var first = secs[0] ? col(secs[0].L) : col(0), last = secs.length ? col(secs[secs.length - 1].L) : col(0);
    var lin = "linear-gradient(180deg," + first + " 0%," + stops.join(",") + "," + last + " 100%)";
    return glows.concat(lin).join(",");
  }
  var raf = 0, ro2 = null, lastPage = null;
  function apply() {
    raf = 0;
    var page = document.querySelector('#pageContent > [data-page="home"]:not(.cm-home-skeleton)');
    if (!page) return;
    /* تم روشن (سفید/مشکی): گرادیان تیره‌ی هوشمند اعمال نشود */
    if (document.documentElement.classList.contains("theme-light")) {
      page.style.removeProperty("background-image");
      page.style.removeProperty("background-size");
      page.style.removeProperty("background-repeat");
      return;
    }
    /* cm-flat-bg */ page.style.removeProperty("background-image"); page.style.removeProperty("background-size"); page.style.removeProperty("background-repeat"); return;
    var secs = analyse(page);
    if (!secs.length) return;
    page.style.setProperty("background-image", build(page, secs), "important");
    page.style.setProperty("background-size", "100% 100%", "important");
    page.style.setProperty("background-repeat", "no-repeat", "important");
    window.CM_SMART_BG = { sections: secs.map(function (s) { return { name: s.name, top: Math.round(s.top), height: Math.round(s.h), lightness: s.L, coverage: +s.cov.toFixed(2), avgContentLum: +s.avg.toFixed(2) }; }) };
  }
  function schedule() { if (!raf) raf = requestAnimationFrame(apply); }
  function bind() {
    var page = document.querySelector('#pageContent > [data-page="home"]');
    if (page === lastPage) return;
    lastPage = page;
    if (ro2) ro2.disconnect();
    if (page && "ResizeObserver" in window) {
      ro2 = new ResizeObserver(schedule);
      ro2.observe(page);
      Array.prototype.forEach.call(page.children, function (c) { ro2.observe(c); });
    }
    schedule();
  }
  function init() {
    var pc = document.getElementById("pageContent");
    if (!pc) return setTimeout(init, 200);
    new MutationObserver(function () { bind(); schedule(); }).observe(pc, { childList: true, subtree: true });
    window.addEventListener("resize", schedule, { passive: true });
    window.addEventListener("load", function () { setTimeout(schedule, 300); });
    bind();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
