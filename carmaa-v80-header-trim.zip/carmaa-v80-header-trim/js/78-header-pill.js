"use strict";
/* CarMaa — هدر کپسولی: روی صفحه‌ی خانه، با اسکرول از هیرو کلاس cm-hdr-pill روی <html> می‌نشیند
   و header-pill.css هدر را داخل باکس شناور (غیر فول‌عرض) می‌برد. */
(function () {
  if (window.__cmHdrPill) return; window.__cmHdrPill = true;

  /* "scroll": باکس از همان ابتدای اسکرول ظاهر می‌شود.
     "hero":   باکس فقط وقتی ظاهر می‌شود که هیرو کامل از زیر هدر رد شده باشد. */
  var MODE = "scroll";
  var START = 16;          /* px — فقط برای حالت scroll */
  var HYST = 10;           /* px — برای جلوگیری از لرزش */

  var root = document.documentElement, on = false, ticking = false;

  function y() { return window.pageYOffset || root.scrollTop || document.body.scrollTop || 0; }
  function isHome() { return !!document.querySelector('#pageContent > [data-page="home"]:not(.cm-home-skeleton)'); }

  function wanted() {
    if (!isHome()) return false;
    if (MODE === "hero") {
      var hero = document.querySelector('#pageContent [data-page="home"] .cm-hh-promo');
      var hdr = document.getElementById("siteHeader");
      if (hero && hdr) {
        var limit = hdr.getBoundingClientRect().bottom + (on ? HYST : 0);
        return hero.getBoundingClientRect().bottom <= limit;
      }
    }
    return y() > (on ? START - HYST / 2 : START);
  }

  function update() {
    ticking = false;
    var v = wanted();
    if (v !== on) { on = v; root.classList.toggle("cm-hdr-pill", v); }
  }
  function req() { if (ticking) return; ticking = true; (window.requestAnimationFrame || setTimeout)(update); }

  window.addEventListener("scroll", req, { passive: true });
  window.addEventListener("resize", req);
  window.addEventListener("pageshow", req);
  window.addEventListener("popstate", req);
  var pc = document.getElementById("pageContent");
  if (pc && "MutationObserver" in window) new MutationObserver(req).observe(pc, { childList: true });
  update();
})();
