"use strict";
/* CarMaa — منوی همبرگری کنار لوگو: کپسول → پنل منو با ساعت زنده و هاور رولینگ */
(function () {
  const LINKS = [
    ["خانه", "goHome", ""],
    ["آگهی‌ها", "goListings", ' data-brand="all"'],
    ["نمایشگاه‌ها", "browseDealers", ""],
    ["اخبار خودرو", "goNews", ""],
    ["نشان‌شده‌ها", "goSaved", ""],
    ["پیام‌ها", "openMessages", ""],
    ["حساب کاربری", "openAccount", ""],
  ];
  const fa = (n) => String(n).replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);
  let btn, overlay, panel, clockEl, timer;

  function build() {
    overlay = document.createElement("div");
    overlay.className = "cm-nav-overlay";
    panel = document.createElement("nav");
    panel.className = "cm-nav-panel";
    panel.setAttribute("aria-label", "منوی اصلی");
    panel.innerHTML =
      '<ul class="cm-nav-list">' +
      LINKS.map((l, i) =>
        '<li><button type="button" class="cm-nav-link" data-action="' + l[1] + '"' + l[2] + ">" +
        '<span class="cm-nav-num">' + fa(String(i + 1).padStart(2, "0")) + "</span>" +
        '<span class="cm-nav-roll"><span>' + l[0] + "</span><span>" + l[0] + "</span></span></button></li>"
      ).join("") +
      '</ul><div class="cm-nav-foot"><span class="cm-nav-clock">تهران<b data-clock>--:--:--</b></span>' +
      '<button type="button" class="cm-nav-cta" data-action="goSell">ثبت آگهی</button></div>';
    document.body.appendChild(overlay);
    document.body.appendChild(panel);
    clockEl = panel.querySelector("[data-clock]");
    overlay.addEventListener("click", close);
    panel.addEventListener("click", (e) => { if (e.target.closest("[data-action]")) setTimeout(close, 60); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
  }

  function tick() {
    try {
      clockEl.textContent = new Intl.DateTimeFormat("fa-IR", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false, timeZone: "Asia/Tehran" }).format(new Date());
    } catch (_) { clockEl.textContent = fa(new Date().toTimeString().slice(0, 8)); }
  }

  function place() {
    const h = document.getElementById("siteHeader");
    const bottom = h ? Math.round(h.getBoundingClientRect().bottom) : 66;
    overlay.style.top = bottom + "px";
    /* وقتی هدر کپسولی است، حلقه‌ی دور باکس ~۸px پایین‌تر می‌آید؛ پنل زیر آن باز شود */
    const pill = document.documentElement.classList.contains("cm-hdr-pill");
    panel.style.top = bottom + (pill ? 16 : 6) + "px";
  }

  function open() {
    if (!panel) build();
    place(); tick(); clearInterval(timer); timer = setInterval(tick, 1000);
    overlay.classList.add("is-open"); panel.classList.add("is-open");
    btn.classList.add("is-open"); btn.setAttribute("aria-expanded", "true");
  }
  function close() {
    if (!panel) return;
    clearInterval(timer);
    overlay.classList.remove("is-open"); panel.classList.remove("is-open");
    if (btn) { btn.classList.remove("is-open"); btn.setAttribute("aria-expanded", "false"); }
  }

  function mount() {
    const row = document.querySelector("#siteHeader .header-home-row");
    if (!row || row.querySelector(".cm-burger")) return;
    btn = document.createElement("button");
    btn.type = "button";
    btn.className = "cm-burger";
    btn.setAttribute("aria-label", "منو");
    btn.setAttribute("aria-expanded", "false");
    btn.innerHTML = "<i></i>";
    btn.addEventListener("click", (e) => { e.stopPropagation(); (panel && panel.classList.contains("is-open")) ? close() : open(); });
    row.appendChild(btn);
  }

  function init() {
    mount();
    /* اگر هدر دوباره ساخته شد، دکمه را برگردان */
    new MutationObserver(() => { if (!document.querySelector(".cm-burger")) mount(); }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
