/* CM-STORIES-PILL v5: گروه دایره‌ای هم‌پوشان (مثل AvatarGroup) + «+N» + دکمه‌ی «+» زیر متن هیرو.
   داده‌ها از ریل استوری‌های صفحه (.cm-ts-rail) خوانده می‌شود. فقط با کلیک روی فلش لیست کامل باز/بسته می‌شود. */
(function () {
  "use strict";
  var sig = "";

  function wrap() { return document.querySelector(".cm-sp-wrap"); }
  function setOpen(w, on) {
    w.setAttribute("data-st", on ? "1" : "0");
    var b = w.querySelector(".cm-sp-more"); if (b) b.setAttribute("aria-expanded", on ? "true" : "false");
    if (!on) { var l = w.querySelector(".cm-sp-list"); if (l) l.scrollLeft = 0; } /* بعد از بستن، لیست به ابتدا برگردد */
  }

  function collect() {
    var out = [], nodes = document.querySelectorAll('.cm-ts-rail .cm-ts-item[data-action="storyOpen"]');
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i], img = n.querySelector(".cm-ts-av img"), nm = n.querySelector(".cm-ts-name");
      out.push({
        owner: n.getAttribute("data-owner") || "",
        unseen: n.classList.contains("is-unseen"),
        src: img ? (img.getAttribute("src") || "") : "",
        letter: !img ? ((n.querySelector(".cm-ts-av") || {}).textContent || "").trim() : "",
        hue: parseInt(((n.querySelector(".cm-ts-av") || {}).style || { getPropertyValue: function () { return ""; } }).getPropertyValue("--h"), 10) || 0,
        name: nm ? nm.textContent.trim() : "",
        label: n.getAttribute("aria-label") || ""
      });
    }
    return out;
  }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fa(n) { try { return Number(n).toLocaleString("fa-IR"); } catch (_) { return String(n); } }

  function item(it) {
    var av = it.src ? '<img src="' + esc(it.src) + '" alt="" draggable="false" decoding="async" data-l="' + esc(it.name.charAt(0)) + '" />'
                    : '<b>' + esc(it.letter.charAt(0)) + '</b>';
    return '<button type="button" class="cm-sp-it' + (it.unseen ? " is-unseen" : "") + '" data-action="storyOpen" data-owner="' + esc(it.owner) +
      '" aria-label="' + esc(it.label || it.name) + '"><span class="cm-sp-ring"><span class="cm-sp-av" style="--h:' + (it.hue || 0) + '">' + av + '</span></span><span class="cm-sp-nm">' + esc(it.name) + '</span></button>';
  }

  var X = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>';
  var PLUS = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';

  function build(w, items) {
    var keep = w.getAttribute("data-st") === "1", n = items.length, extra = n - 5;
    w.innerHTML =
      '<div class="cm-sp-grp">' +
        '<div class="cm-sp-list" role="list">' + items.map(item).join("") + '</div>' +
        (extra > 0 ? '<button type="button" class="cm-sp-more" data-sp="toggle" aria-label="نمایش همه استوری‌ها" aria-expanded="false">' +
          '<span class="cm-sp-count">+' + fa(extra) + '</span>' + X + '</button>' : "") +
      '</div>' +
      '<button type="button" class="cm-sp-add" data-action="storyAdd" aria-label="افزودن استوری">' + PLUS + '</button>';
    w.hidden = false;
    setOpen(w, keep && extra > 0);
  }

  function sync() {
    var w = wrap(); if (!w) { sig = ""; return; }
    if (!document.querySelector(".cm-ts:not(.cm-ts-skeleton) .cm-ts-rail")) { w.hidden = true; sig = ""; return; } /* تا لود شدن ریل استوری‌ها چیزی نشان نده */
    var items = collect();
    var s = items.map(function (i) { return i.owner + "|" + (i.unseen ? 1 : 0) + "|" + i.src + "|" + i.name; }).join("~");
    if (s !== sig || !w.querySelector(".cm-sp-add")) { sig = s; build(w, items); } /* حتی بدون استوری، دکمه‌ی «+» می‌ماند */
  }

  /* اگر عکس پروفایل لود نشد، حرف اول با پس‌زمینه‌ی رنگی نشان بده */
  document.addEventListener("error", function (e) {
    var im = e.target; if (!im || im.tagName !== "IMG" || !im.closest || !im.closest(".cm-sp-av")) return;
    var b = document.createElement("b"); b.textContent = im.getAttribute("data-l") || "م"; im.replaceWith(b);
  }, true);

  document.addEventListener("click", function (e) {
    var w = wrap(); if (!w) return;
    var t = e.target.closest ? e.target.closest(".cm-sp-more") : null;
    if (t) { e.preventDefault(); e.stopImmediatePropagation(); setOpen(w, w.getAttribute("data-st") !== "1"); return; }
    if (w.getAttribute("data-st") !== "1") return;
    var inside = e.target.closest && e.target.closest(".cm-sp-grp"), story = e.target.closest && e.target.closest(".cm-sp-it");
    if (!inside || story) setOpen(w, false); /* کلیک روی استوری یا بیرون = بسته شدن */
  }, true);

  setInterval(sync, 1500);
  document.addEventListener("DOMContentLoaded", sync);
  window.addEventListener("pageshow", sync);
})();
