/* Local preview boot guard. Loaded last, after every app script. */
(function () {
  if (!window.CARMA_LOCAL_PREVIEW) return;
  function bootLocalPreview() {
    window.CARMA_BOOT_DONE = true;
    try { if (window.CARMA_DEMO && typeof window.CARMA_DEMO.apply === 'function') window.CARMA_DEMO.apply(); } catch (e) { console.warn('[CarMaa local preview] demo data:', e); }
    var content = document.getElementById('pageContent');
    if (!content) return;
    // The normal initializer may have been skipped by a browser's file-origin
    // restrictions. Retry the real app renderer after all deferred scripts ran.
    if (typeof window.render === 'function') {
      try { window.render(); } catch (e) { console.error('[CarMaa local preview] render failed:', e); }
    }
    // A second attempt catches startup code that registered its own DOM-ready
    // callback after a browser-specific event ordering difference.
    window.setTimeout(function () {
      var skeleton = document.getElementById('bootSkeleton');
      var hasRealPage = content.querySelector('[data-page]:not(#bootSkeleton)') || content.children.length > 1 || (content.firstElementChild && content.firstElementChild.id !== 'bootSkeleton');
      if (hasRealPage) return;
      if (typeof window.render === 'function') {
        try { window.render(); } catch (e) { console.error('[CarMaa local preview] retry failed:', e); }
      }
      hasRealPage = content.querySelector('[data-page]:not(#bootSkeleton)') || content.children.length > 1 || (content.firstElementChild && content.firstElementChild.id !== 'bootSkeleton');
      if (hasRealPage) return;
      if (skeleton) skeleton.remove();
      var notice = document.createElement('section');
      notice.dir = 'rtl';
      notice.style.cssText = 'max-width:520px;margin:24px auto;padding:28px 20px;text-align:center;color:#222;background:#fff;border-radius:18px;font:14px/2 Vazirmatn,Tahoma,sans-serif;';
      notice.innerHTML = '<h2 style="margin:0 0 10px;font-size:19px">پیش‌نمایش محلی CarMaa</h2><p>بخشی از اسکریپت‌های برنامه در این مرورگر اجرا نشدند. لطفاً فایل OPEN-CARMA-ON-LAPTOP.bat را اجرا کن تا سایت از طریق سرور محلی باز شود.</p><p style="font-size:12px;color:#666">اگر این پیام را می‌بینی، خطای اجرای جاوااسکریپت در کنسول مرورگر ثبت شده است.</p>';
      content.replaceChildren(notice);
    }, 1200);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bootLocalPreview, { once: true });
  else bootLocalPreview();
})();
