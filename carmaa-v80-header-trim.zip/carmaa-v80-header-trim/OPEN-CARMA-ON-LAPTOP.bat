@echo off
setlocal
cd /d "%~dp0"
set "PORT=8765"

where py >nul 2>nul
if %errorlevel%==0 (
  set "PYTHON=py -3"
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    set "PYTHON=python"
  ) else (
    echo Python 3 was not found.
    echo You can still double-click index.html; direct file preview is supported now.
    pause
    exit /b 1
  )
)

start "CarMaa local preview server" /D "%~dp0" %PYTHON% -m http.server %PORT% --bind 127.0.0.1
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:%PORT%/index.html?localPreview=1"
echo.
echo CarMaa preview opened in your browser.
echo Keep the server window open while using the preview.
endlocal
